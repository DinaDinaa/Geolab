﻿using QuizPlatform.Identity.Requests;

namespace QuizPlatform.Identity.Services.Abstractions;

public interface IIdentityService
{
    Task<string> AuthenticateAsync(LoginRequest request);

    Task<string?> RegisterAsync(RegisterRequest request);

    Task ConfirmEmail(ConfirmEmailRequest request);

    Task<string> ChangePasswordAsync(ChangePasswordRequest request);

    Task ResetPasswordAsync(ResetPasswordRequest request);

    Task NewPasswordAsync(NewPasswordRequest request);
}